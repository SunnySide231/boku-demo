package com.ma.boku.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ma.boku.pojo.Product;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductMapper extends BaseMapper<Product> {
    @Select("select * from product")
    List<Product> productList(Product product);

    @Select("select * from product where id = #{id}")
    Product findByID(Integer id);

    @Select("select * from product where productname like '%${name}%'")
    List<Product> selproductList(String name);

    @Delete("delete from product where id = #{id}")
    int deleteByID(Integer id);

    @Update("update product set productname = #{productname},productimg = #{productimg},price = #{price},productnum = #{productnum} where id = #{id}")
    int SchoolUpdate(Product product);

    @Update("update product set productname = #{productname},price = #{price},productnum = #{productnum} where id = #{id}")
    int SchoolUpdate2(Product product);

    @Insert("insert into product (productname,price,productimg,productnum) values(#{productname},#{price},#{productimg},#{productnum})")
//    @Insert("insert into product (productname,price,productnum) values(#{productname},#{price},#{productnum})")
    int insert1(Product product);
}
