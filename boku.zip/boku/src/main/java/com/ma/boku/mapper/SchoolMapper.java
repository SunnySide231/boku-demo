package com.ma.boku.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ma.boku.pojo.School;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SchoolMapper extends BaseMapper<School> {
    @Select("select * from school")
    List<School> getList(School school);

    @Select("select * from school where id = #{id}")
    School findByID(Integer id);

    @Update("update school set schoolname = #{schoolname},img = #{img},address = #{address},introduction = #{introduction} where id = #{id}")
    int SchoolUpdate(School school);

    @Update("update school set schoolname = #{schoolname},address = #{address},introduction = #{introduction} where id = #{id}")
    int SchoolUpdate2(School school);

    @Select("select * from school where schoolname like '%${name}%' or address like '%${name}%' or introduction like '%${name}%'")
    List<School> sellist(String name);
}
