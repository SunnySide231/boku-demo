package com.ma.boku.service;

import com.ma.boku.mapper.AccountMapper;
import com.ma.boku.pojo.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AccountServiceImpl implements AccountService {
    @Autowired
    private AccountMapper accountMapper;

    @Override
    public List<User> userList() {
        return accountMapper.userList();
    }

    @Override
    public User findByID(Integer id) {
        return accountMapper.findByID(id);
    }

    @Override
    public int upd(User user) {
        return accountMapper.upd(user);
    }

    @Override
    public int del(int id) {
        return accountMapper.del(id);
    }

    @Override
    public List<User> seluserList(String name) {
        return accountMapper.seluserList(name);
    }

}