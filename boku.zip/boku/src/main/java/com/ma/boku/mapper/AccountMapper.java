package com.ma.boku.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ma.boku.pojo.User;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AccountMapper extends BaseMapper<User> {
    @Select("select * from user")
    List<User> userList();

    @Select("select * from user where id = #{id}")
    User findByID(Integer id);

    @Update("update user set username=#{username},password = #{password} where id = #{id}")
    int upd(User user);

    @Delete("delete from user where id = #{id}")
    int del(int id);

    @Select("select * from user where id like '%${name}%' or account like '%${name}%' or username like '%${name}%' or password like '%${name}%'")
    List<User> seluserList(String name);
}
