package com.ma.boku.service;

import com.ma.boku.mapper.IntegralMapper;
import com.ma.boku.pojo.Integral;
import com.ma.boku.pojo.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class IntegralServiceImpl implements IntegralService {
    @Autowired
    private IntegralMapper integralMapper;

    @Override
    public List<User> integralList() {
        return integralMapper.integralList();
    }

    @Override
    public List<User> selintegralList(String name) {
        return integralMapper.selintegralList(name);
    }

    @Override
    public User findByID(Integer id) {
        return integralMapper.findByID(id);
    }

    @Override
    public int upd(User user) {
        return integralMapper.upd(user);
    }
}
