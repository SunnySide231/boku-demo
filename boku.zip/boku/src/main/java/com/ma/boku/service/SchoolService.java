package com.ma.boku.service;

import com.ma.boku.pojo.School;

import java.util.List;

public interface SchoolService {
    List<School> getList(School school);

    School findByID(Integer id);

    int insert(School school);

    int SchoolUpdate(School school);

    int deleteByID(Integer id);

    int SchoolUpdate2(School school);

    List<School> sellist(String name);
}
