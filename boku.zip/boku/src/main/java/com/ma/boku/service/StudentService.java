package com.ma.boku.service;

import com.ma.boku.pojo.School;
import com.ma.boku.pojo.User;

import java.util.List;

public interface StudentService {
    List<School> studentList(School school);

    School findByID(Integer id);

    List<School> findschool();

    int add(User user);

    int upd(User user);

    int del(int id);

    List<School> studentList1(String name);
}
