package com.ma.boku.service;

import com.ma.boku.mapper.SchoolMapper;
import com.ma.boku.pojo.School;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SchoolServiceImpl implements SchoolService{
    @Autowired
    private SchoolMapper schoolMapper;
    @Override
    public List<School> getList(School school) {
        return schoolMapper.getList(school);
    }

    @Override
    public School findByID(Integer id) {
        return schoolMapper.findByID(id);
    }

    @Override
    public int insert(School school) {
        return schoolMapper.insert(school);
    }

    @Override
    public int SchoolUpdate(School school) {
        return schoolMapper.SchoolUpdate(school);
    }

    @Override
    public int deleteByID(Integer id) {
        return schoolMapper.deleteById(id);
    }

    @Override
    public int SchoolUpdate2(School school) {
        return schoolMapper.SchoolUpdate2(school);
    }

    @Override
    public List<School> sellist(String name) {
        return schoolMapper.sellist(name);
    }


}
