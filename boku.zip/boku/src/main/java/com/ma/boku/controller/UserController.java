package com.ma.boku.controller;

import com.ma.boku.pojo.User;
import com.ma.boku.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
@RequestMapping("/user")
public class UserController {
    @Autowired
    private UserService userService;

    @RequestMapping("/login")
    public String login(String account, String password, HttpSession session) {
        User user = userService.login(account, password);
        if ("".equals(user) | user == null) {
            return "login";
        }

        session.setAttribute("user", user);
        return "main";
    }

    @RequestMapping("/loginout")
    public String loginout(HttpSession session) {
        session.removeAttribute("user");
        return "login";
    }

//    @RequestMapping("/selectUserByScId")
//    public String selectUserByScId(String  rname , HttpSession session){
//        List<User> userList = userService.selectUserByScId(rname);
//        session.setAttribute("userList",userList);
//        return "school_list";
//    }


    @RequestMapping("/welcome")
    public String welcome() {
        return "welcome";
    }

    @RequestMapping("/tologin")
    public String tologin() {
        return "login";
    }


}
