package com.ma.boku.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.ma.boku.pojo.School;
import com.ma.boku.pojo.User;
import com.ma.boku.service.StudentService;
import com.ma.boku.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
@RequestMapping("/student")
public class StudentController {
    @Autowired
    private StudentService studentService;
    @Autowired
    private UserService userService;

    @RequestMapping("/list")
    public String list(School school, Model model, @RequestParam(defaultValue = "1") int pageNum, @RequestParam(defaultValue = "10") int pageSize){
        PageHelper.startPage(pageNum,pageSize);
        List<School> student_list = studentService.studentList(school);
        PageInfo<School> studentPageInfo = new PageInfo<School>(student_list);
        model.addAttribute("studentPageInfo",studentPageInfo);
        return "student_list";
    }

    @RequestMapping("/edit")
    public String edit(String name,School school, Model model,HttpSession session, @RequestParam(defaultValue = "1") int pageNum, @RequestParam(defaultValue = "8") int pageSize){
        PageHelper.startPage(pageNum,pageSize);
        if (name==null){
            List<School> student_list = studentService.studentList(school);
            PageInfo<School> studentPageInfo = new PageInfo<School>(student_list);
            model.addAttribute("studentPageInfo",studentPageInfo);
            model.addAttribute("name",name);
        }else{
            List<School> student_list1 = studentService.studentList1(name);
            PageInfo<School> studentPageInfo = new PageInfo<School>(student_list1);
            model.addAttribute("studentPageInfo",studentPageInfo);
            model.addAttribute("name",name);
        }

        return "student_edit";
    }
    @RequestMapping("/findByID")
    @ResponseBody
    public School account_findByID(Integer id) {
        School school = studentService.findByID(id);
        return school;
    }

    @RequestMapping("/findschool")
    @ResponseBody
    public List<School> account_findByID() {
        List<School> school = studentService.findschool();
        return school;
    }

    @RequestMapping("/add")
    @ResponseBody
    public int add(User user) {
        int i = studentService.add(user);
        if (i>0){
            return i;
        }
        return 0;
    }

    @RequestMapping("/upd")
    @ResponseBody
    public int upd(User user) {
        int i = studentService.upd(user);
        if (i > 0) {
            return i;
        }
        return 0;
    }

    @RequestMapping("/del")
    public String del(int id){
        int i = studentService.del(id);
        if (i>0){
            return "redirect:/student/edit";
        }
        return "404";
    }
}
