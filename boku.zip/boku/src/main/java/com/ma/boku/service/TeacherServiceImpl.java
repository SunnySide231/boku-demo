package com.ma.boku.service;

import com.ma.boku.mapper.TeacherMapper;
import com.ma.boku.pojo.School;
import com.ma.boku.pojo.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class TeacherServiceImpl implements TeacherService{
    @Autowired
    private TeacherMapper teacherMapper;
    @Override
    public List<School> teacherList(School school) {
        return teacherMapper.getList(school);
    }

    @Override
    public School findByID(Integer id) {
        return teacherMapper.findByID(id);
    }

    @Override
    public List<School> selteacher(String name) {
        return teacherMapper.selteacher(name);
    }

    @Override
    public int add(User user) {
        return teacherMapper.add(user);
    }

    @Override
    public int upd(User user) {
        return teacherMapper.upd(user);
    }

    @Override
    public int deleteByid(int id) {
        return teacherMapper.deleteByid(id);
    }

}
