package com.ma.boku.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ma.boku.pojo.Integral;
import com.ma.boku.pojo.User;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IntegralMapper extends BaseMapper<Integral> {

    @Select("select id,username,integral from user")
    List<User> integralList();

    @Select("select * from user where username like '%${name}%' or integral like '%${name}%'")
    List<User> selintegralList(String name);

    @Select("select id,username,integral from user where id=#{id}")
    User findByID(Integer id);

    @Update("update user set integral = #{integral} where id = #{id}")
    int upd(User user);
}
