package com.ma.boku.service;

import com.ma.boku.pojo.Integral;
import com.ma.boku.pojo.User;

import java.util.List;

public interface IntegralService {

    List<User> integralList();

    List<User> selintegralList(String name);

    User findByID(Integer id);

    int upd(User user);
}
