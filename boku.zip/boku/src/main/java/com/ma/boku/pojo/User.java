package com.ma.boku.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class User {
    @TableId(value="id",type=IdType.AUTO)
    private Integer id;
    private String account;
    private String username;
    private String password;
    private String tel;
    private String home;
    private Integer schoolid;
    private Integer rid;
    private Role role;
    private int integral;
}
