package com.ma.boku.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.ma.boku.pojo.School;
import com.ma.boku.service.SchoolService;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.ResourceUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Controller
@RequestMapping("/school")
public class SchoolController {
    @Autowired
    private SchoolService schoolService;

    @RequestMapping("/list")
    public String school_list(School school, Model model, @RequestParam(defaultValue = "1") int pageNum, @RequestParam(defaultValue = "3") int pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        List<School> school_list = schoolService.getList(school);
        PageInfo<School> schoolPageInfo = new PageInfo<School>(school_list);
        model.addAttribute("schoolPageInfo", schoolPageInfo);
        return "school_list";
    }



    @RequestMapping("/findByID")
    @ResponseBody
    public School account_findByID(Integer id, HttpSession session) {
        School school = schoolService.findByID(id);
        session.setAttribute("school", school);
        return school;
    }

    @RequestMapping("/deleteByID")
    @ResponseBody
    public int deleteByID(Integer id) {
        int i = schoolService.deleteByID(id);
        return i;
    }

    @RequestMapping("/upload")
    public String uploadImg(HttpServletRequest req, @RequestParam("file") MultipartFile file, School school) throws Exception {
        // 获取文件的原始名称
        String fileName = file.getOriginalFilename();
        // 获取文件的后缀
        String extension = FilenameUtils.getExtension(file.getOriginalFilename());
        // 根据日期动态的生成目录
        String localContainer = "/static/upload";
        String uploadPath = ResourceUtils.getURL("src/main/resources").getPath() + localContainer;
        String dateFormat = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
        File dateDirPath = new File(uploadPath + File.separator + dateFormat);
        if (!dateDirPath.exists()) {
            dateDirPath.mkdirs();
        }
        String session01 = localContainer.substring(localContainer.lastIndexOf("/")) + "/" + dateFormat + "/" + fileName;
        // 处理文件上传
        file.transferTo(new File(dateDirPath, fileName));
        //添加
        school.setImg(session01);
        int i = schoolService.insert(school);
        return "redirect:/school/sel";
    }

    @RequestMapping("/update")
    public String update(HttpServletRequest req, @RequestParam("file") MultipartFile file, HttpSession session) throws Exception {
        // 获取文件的原始名称
        String fileName = file.getOriginalFilename();
        // 获取文件的后缀
        String extension = FilenameUtils.getExtension(file.getOriginalFilename());
        // 根据日期动态的生成目录
        String localContainer = "/static/upload";
        String uploadPath = ResourceUtils.getURL("src/main/resources").getPath() + localContainer;
        String dateFormat = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
        File dateDirPath = new File(uploadPath + File.separator + dateFormat);
        if (!dateDirPath.exists()) {
            dateDirPath.mkdirs();
        }
        String session01 = localContainer.substring(localContainer.lastIndexOf("/")) + "/" + dateFormat + "/" + fileName;
        // 处理文件上传
        file.transferTo(new File(dateDirPath, fileName));
        School school = (School) session.getAttribute("school");
        //添加
        school.setImg(session01);
        System.out.println(school.getImg());
        System.out.println(school);
        int i = schoolService.SchoolUpdate(school);
        return "redirect:/school/sel";
    }

    @ResponseBody
    @RequestMapping("/upd")
    public int update2(School school) {

        int i = schoolService.SchoolUpdate2(school);
        return i;
    }

    //@ResponseBody
    @RequestMapping("/sel")
    public String sellist(School school,String name, Model model, @RequestParam(defaultValue = "1") int pageNum, @RequestParam(defaultValue = "3") int pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        //name = name==null ? "null":name ;

        if (name==null){
            List<School> sellist = schoolService.getList(school);
            PageInfo<School> schoolPageInfo = new PageInfo<School>(sellist);
            model.addAttribute("schoolPageInfo", schoolPageInfo);
            model.addAttribute("name", name);
        }else{
            List<School> sellist = schoolService.sellist(name);
            PageInfo<School> schoolPageInfo = new PageInfo<School>(sellist);
            model.addAttribute("schoolPageInfo", schoolPageInfo);
            model.addAttribute("name", name);

        }
        return "school_edit";
    }
}
