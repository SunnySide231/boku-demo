package com.ma.boku.demo;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;

@RestController
public class UploadDemo {
    @RequestMapping("/upload")
    public void upload(@RequestParam("file")MultipartFile file) throws Exception{
        // 上传的文件存放的路径，默认在项目的根目录下
        String filePath = file.getOriginalFilename();
        // 输出流
        BufferedOutputStream outputStream = new BufferedOutputStream(new FileOutputStream(filePath));
        // 写入
        outputStream.write(file.getBytes());
        // 关闭流
        outputStream.flush();
        outputStream.close();
    }
}
