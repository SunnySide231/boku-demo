/*
Navicat MySQL Data Transfer

Source Server         : mysql
Source Server Version : 50731
Source Host           : localhost:3306
Source Database       : boku

Target Server Type    : MYSQL
Target Server Version : 50731
File Encoding         : 65001

Date: 2020-10-22 09:10:04
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for product
-- ----------------------------
DROP TABLE IF EXISTS `product`;
CREATE TABLE `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `productname` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `productimg` varchar(255) DEFAULT NULL,
  `updatetime` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `createtime` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `productnum` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of product
-- ----------------------------
INSERT INTO `product` VALUES ('2', '商品一', '111', '/upload/2020-10-15/BG2.jpg', '2020-10-16 14:45:22', '2020-10-16 14:45:22', '11');
INSERT INTO `product` VALUES ('5', '商品二', '211', '15/BG2.jpg', '2020-10-16 14:45:29', '2020-10-16 14:45:29', '3');
INSERT INTO `product` VALUES ('6', '商品三', '222', '/upload/2020-10-15/bean3.jpg', '2020-10-16 14:45:34', '2020-10-16 14:45:34', '222');

-- ----------------------------
-- Table structure for role
-- ----------------------------
DROP TABLE IF EXISTS `role`;
CREATE TABLE `role` (
  `rid` int(11) NOT NULL AUTO_INCREMENT,
  `rolename` varchar(255) NOT NULL,
  PRIMARY KEY (`rid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of role
-- ----------------------------
INSERT INTO `role` VALUES ('1', '管理员');
INSERT INTO `role` VALUES ('2', '教师');
INSERT INTO `role` VALUES ('3', '学生');

-- ----------------------------
-- Table structure for school
-- ----------------------------
DROP TABLE IF EXISTS `school`;
CREATE TABLE `school` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `schoolname` varchar(255) NOT NULL,
  `img` varchar(255) DEFAULT NULL,
  `address` varchar(255) NOT NULL,
  `introduction` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of school
-- ----------------------------
INSERT INTO `school` VALUES ('1', '学校一', '/upload/2020-10-12/shizijia2.jpg', '河南', '123');
INSERT INTO `school` VALUES ('3', '学校二', '/upload/2020-10-07/bean3.jpg', '山东', '2');
INSERT INTO `school` VALUES ('4', '学校三', '/upload/2020-10-07/bean1.jpg', '湖北', '1');
INSERT INTO `school` VALUES ('5', '学校四', '/upload/2020-10-07/bean1.jpg', '湖南', 'xuexiao');
INSERT INTO `school` VALUES ('6', '学校五', '/upload/2020-10-14/bean6.jpg', '河北', '1');
INSERT INTO `school` VALUES ('7', '学校六', '/upload/2020-10-14/bean3.jpg', '黑龙江', 'qwer');
INSERT INTO `school` VALUES ('8', '学校七', '/upload/2020-10-14/bean4.jpg', '辽宁', '123');
INSERT INTO `school` VALUES ('9', '学校八', '/upload/2020-10-15/bean2.jpg', '吉林', '2');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `tel` varchar(11) NOT NULL,
  `home` varchar(255) NOT NULL,
  `schoolid` int(11) NOT NULL,
  `rid` int(11) NOT NULL,
  `integral` int(11) unsigned zerofill DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_Reference_1` (`schoolid`),
  KEY `FK_Reference_3` (`rid`),
  CONSTRAINT `FK_Reference_1` FOREIGN KEY (`schoolid`) REFERENCES `school` (`id`),
  CONSTRAINT `FK_Reference_3` FOREIGN KEY (`rid`) REFERENCES `role` (`rid`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', 'user001', '用户一1', '111', '110', '中国北京', '1', '1', '00000000002');
INSERT INTO `user` VALUES ('4', 'user004', '用户四', '444', '114', '中国香港', '1', '2', '00000000000');
INSERT INTO `user` VALUES ('6', 'user006', '用户六', '666', '10001', '中国天津', '1', '2', '00000000000');
INSERT INTO `user` VALUES ('8', 'user008', '用户八', '888', '1001011', '中国河北', '1', '2', '00000000000');
INSERT INTO `user` VALUES ('9', 'user009', '用户九', '999', '1008611', '中国三门峡', '1', '2', '00000000000');
INSERT INTO `user` VALUES ('10', 'user010', '用户十', '010', '1000111', '中国西平', '1', '2', '00000000000');
INSERT INTO `user` VALUES ('11', 'user011', '用户十一', '011', '1000111', '中国西平', '1', '2', '00000000000');
INSERT INTO `user` VALUES ('12', 'user012', '用户十二', '012', '1000111', '中国西平', '1', '2', '00000000000');
INSERT INTO `user` VALUES ('13', 'user012', '用户十三', '013', '10000', '中国', '1', '2', '00000000000');
INSERT INTO `user` VALUES ('14', 'user007', '用户12345678', '777', '10086', '中国南京', '4', '3', '00000000000');
INSERT INTO `user` VALUES ('15', 'user007', '用户七', '777', '10086', '中国南京', '1', '2', '00000000000');
INSERT INTO `user` VALUES ('33', '5927', '925927', '857', '9527', '中华人民共和国', '1', '2', '00000000000');
INSERT INTO `user` VALUES ('35', 'usertwo', '小明', 'two', '12344321', '哥伦比亚', '3', '2', '00000000000');
INSERT INTO `user` VALUES ('36', 'usertwo', '儿童与', '二try图', '围绕太阳看', '让他云', '4', '2', '00000000000');
INSERT INTO `user` VALUES ('38', '1', '1', '1', '1', '1', '4', '2', '00000000000');
INSERT INTO `user` VALUES ('39', '1', '1', '1', '1', '1', '5', '3', '00000000000');
