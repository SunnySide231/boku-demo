package com.ma.boku.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.ma.boku.pojo.Integral;
import com.ma.boku.pojo.School;
import com.ma.boku.pojo.User;
import com.ma.boku.service.IntegralService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
@RequestMapping("/integral")
public class IntegralController {
    @Autowired
    private IntegralService integralService;

    @RequestMapping("/list")
    public String integral_list(Model model, @RequestParam(defaultValue = "1") int pageNum, @RequestParam(defaultValue = "10") int pageSize) {
        PageHelper.startPage(pageNum,pageSize);
        List<User> integralList = integralService.integralList();
        PageInfo<User> integralPageInfo = new PageInfo<User>(integralList);
        model.addAttribute("integralPageInfo",integralPageInfo);
        return "integral_list";
    }
    @RequestMapping("/edit")
    public String integral_edit(String name, Model model,@RequestParam(defaultValue = "1") int pageNum, @RequestParam(defaultValue = "8") int pageSize) {
        PageHelper.startPage(pageNum,pageSize);
        if (name==null){
            List<User> integralList = integralService.integralList();
            PageInfo<User> integralPageInfo = new PageInfo<User>(integralList);
            model.addAttribute("integralPageInfo",integralPageInfo);
            model.addAttribute("name",name);
        }else{
            List<User> integralList = integralService.selintegralList(name);
            PageInfo<User> integralPageInfo = new PageInfo<User>(integralList);
            model.addAttribute("integralPageInfo",integralPageInfo);
            model.addAttribute("name",name);

        }
        return "integral_edit";
    }
    @RequestMapping("/findByID")
    @ResponseBody
    public User account_findByID(Integer id) {
        User integral = integralService.findByID(id);
        return integral;
    }
    @RequestMapping("/upd")
    @ResponseBody
    public int upd(User user) {
        int i = integralService.upd(user);
        if (i>0){
            return i;
        }
        return 0;
    }
}
