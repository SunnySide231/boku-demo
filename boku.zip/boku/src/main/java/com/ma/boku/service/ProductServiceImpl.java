package com.ma.boku.service;

import com.ma.boku.mapper.ProductMapper;
import com.ma.boku.pojo.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductServiceImpl implements ProductService {
    @Autowired
    private ProductMapper productMapper;
    @Override
    public List<Product> productList(Product product) {
        return productMapper.productList(product);
    }

    @Override
    public Product findByID(Integer id) {
        return productMapper.findByID(id);
    }

    @Override
    public List<Product> selproductList(String name) {
        return productMapper.selproductList(name);
    }

    @Override
    public int deleteByID(Integer id) {
        return productMapper.deleteByID(id);
    }

    @Override
    public int insert1(Product product) {
        return productMapper.insert1(product);
    }

    @Override
    public int SchoolUpdate(Product product) {
        return productMapper.SchoolUpdate(product);
    }

    @Override
    public int SchoolUpdate2(Product product) {
        return productMapper.SchoolUpdate2(product);
    }
}
