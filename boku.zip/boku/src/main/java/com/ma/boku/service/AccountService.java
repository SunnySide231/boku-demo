package com.ma.boku.service;

import com.baomidou.mybatisplus.core.injector.methods.SelectById;
import com.ma.boku.pojo.User;

import java.util.List;

public interface AccountService {
    List<User> userList();

    User findByID(Integer id);

    int upd(User user);

    int del(int id);

    List<User> seluserList(String name);
}
