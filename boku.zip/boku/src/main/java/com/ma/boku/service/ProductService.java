package com.ma.boku.service;

import com.ma.boku.pojo.Product;

import java.util.List;

public interface ProductService {
    List<Product> productList(Product product);

    Product findByID(Integer id);

    List<Product> selproductList(String name);

    int deleteByID(Integer id);

    int insert1(Product product);

    int SchoolUpdate(Product product);

    int SchoolUpdate2(Product product);
}
