package com.ma.boku.service;

import com.ma.boku.pojo.School;
import com.ma.boku.pojo.User;

import java.util.List;

public interface TeacherService {
    List<School> teacherList(School school);

    School findByID(Integer id);

    List<School> selteacher(String name);

    int add(User user);

    int upd(User user);

    int deleteByid(int id);
}
