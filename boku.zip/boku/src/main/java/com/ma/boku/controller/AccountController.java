package com.ma.boku.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.ma.boku.pojo.School;
import com.ma.boku.pojo.User;
import com.ma.boku.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
@RequestMapping("/account")
public class AccountController {
    @Autowired
    private AccountService accountService;

    @RequestMapping("/list")
    public String account_list( Model model, @RequestParam(defaultValue = "1") int pageNum, @RequestParam(defaultValue = "10") int pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        List<User> userList = accountService.userList();
        PageInfo<User> userPageInfo = new PageInfo<User>(userList);
        model.addAttribute("userPageInfo", userPageInfo);
        return "account_list";
    }

    @RequestMapping("/edit")
    public String account_edit(String name, Model model, @RequestParam(defaultValue = "1") int pageNum, @RequestParam(defaultValue = "8") int pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        if (name==null){
            List<User> userList = accountService.userList();
            PageInfo<User> userPageInfo = new PageInfo<User>(userList);
            model.addAttribute("userPageInfo", userPageInfo);
            model.addAttribute("name",name);
        }else{
            List<User> userList = accountService.seluserList(name);
            PageInfo<User> userPageInfo = new PageInfo<User>(userList);
            model.addAttribute("userPageInfo", userPageInfo);
            model.addAttribute("name",name);
        }
        return "account_edit";
    }

    @RequestMapping("/findByID")
    @ResponseBody
    public User account_findByID(Integer id) {
        User user = accountService.findByID(id);
        return user;
    }

    @RequestMapping("/upd")
    @ResponseBody
    public int upd(User user) {
        int i = accountService.upd(user);
        if (i > 0) {
            return i;
        }
        return 0;
    }
    @RequestMapping("/del")
    public String del(int id) {
        int i = accountService.del(id);
        if (i > 0) {
            return "redirect:/account/edit";
        }
        return "404";
    }
}
