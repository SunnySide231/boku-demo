package com.ma.boku.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ma.boku.pojo.User;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserMapper extends BaseMapper<User>{
    @Select("select * from user where account = #{account} and password = #{password}")
    User login(String account,String password);
    @Select("\n" +
            "SELECT\n" +
            "u.id ,u.username,s.schoolname\n" +
            "FROM `user`  u\n" +
            "LEFT JOIN\n" +
            "role  r\n" +
            "ON  r.rid = u.rid\n" +
            "JOIN school  s\n" +
            "ON u.schoolid   = s.id\n" +
            "WHERE r.rolename=#{rolename}\n" +
            "AND s.id = 1\n")
    List<User> selectUserByScId(String rname);
}
