package com.ma.boku.service;

import com.ma.boku.pojo.User;

import java.util.List;

public interface UserService {
    User login(String account, String password);

    List<User>  selectUserByScId(String rname);

    int insert(User user);
}
