package com.ma.boku.service;

import com.ma.boku.mapper.UserMapper;
import com.ma.boku.pojo.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService{
    @Autowired
    private UserMapper userMapper;
    @Override
    public User login(String account, String password) {
        return userMapper.login(account,password);
    }

    @Override
    public List<User> selectUserByScId(String rname) {
        return userMapper.selectUserByScId(rname);
    }

    @Override
    public int insert(User user) {
        return userMapper.insert(user);
    }
}
