package com.ma.boku.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.ma.boku.pojo.Product;
import com.ma.boku.pojo.School;
import com.ma.boku.pojo.User;
import com.ma.boku.service.ProductService;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.ResourceUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Controller
@RequestMapping("/product")
public class ProductController {
    @Autowired
    private ProductService productService;
    @RequestMapping("/list")
    public String product_list(Product product, Model model, @RequestParam(defaultValue = "1") int pageNum, @RequestParam(defaultValue = "3") int pageSize){
        PageHelper.startPage(pageNum, pageSize);
        List<Product> productList = productService.productList(product);
        PageInfo<Product> productPageInfo = new PageInfo<Product>(productList);
        model.addAttribute("productPageInfo", productPageInfo);
        return "product_list";
    }
    @RequestMapping("/sel")
    public String product_edit(String name,Product product, Model model, @RequestParam(defaultValue = "1") int pageNum, @RequestParam(defaultValue = "3") int pageSize){
        PageHelper.startPage(pageNum, pageSize);
        if (name==null){
            List<Product> productList = productService.productList(product);
            PageInfo<Product> productPageInfo = new PageInfo<Product>(productList);
            model.addAttribute("productPageInfo", productPageInfo);
            model.addAttribute("name", name);
        }else{
            List<Product> productList = productService.selproductList(name);
            PageInfo<Product> productPageInfo = new PageInfo<Product>(productList);
            model.addAttribute("productPageInfo", productPageInfo);
            model.addAttribute("name", name);
        }
        List<Product> productList = productService.productList(product);
        model.addAttribute("productList",productList);
        return "product_edit";
    }
    @RequestMapping("/findByID")
    @ResponseBody
    public Product account_findByID(Integer id,HttpSession session) {
        Product product = productService.findByID(id);
        session.setAttribute("product", product);
        return product;
    }
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    @RequestMapping("/deleteByID")
    @ResponseBody
    public int deleteByID(Integer id) {
        int i = productService.deleteByID(id);
        return i;
    }
    @RequestMapping("/upload")
    public String uploadImg(HttpServletRequest req, @RequestParam("file") MultipartFile file, Product product) throws Exception {
        // 获取文件的原始名称
        String fileName = file.getOriginalFilename();
        // 获取文件的后缀
        String extension = FilenameUtils.getExtension(file.getOriginalFilename());
        // 根据日期动态的生成目录
        String localContainer = "/static/upload";
        String uploadPath = ResourceUtils.getURL("src/main/resources").getPath() + localContainer;
        String dateFormat = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
        File dateDirPath = new File(uploadPath + File.separator + dateFormat);
        if (!dateDirPath.exists()) {
            dateDirPath.mkdirs();
        }
        String session01 = localContainer.substring(localContainer.lastIndexOf("/")) + "/" + dateFormat + "/" + fileName;
        // 处理文件上传
        file.transferTo(new File(dateDirPath, fileName));
        //添加
        product.setProductimg(session01);
        int i = productService.insert1(product);
        return "redirect:/product/sel";
    }

    @RequestMapping("/update")
    public String update(HttpServletRequest req, @RequestParam("file") MultipartFile file, HttpSession session) throws Exception {
        // 获取文件的原始名称
        String fileName = file.getOriginalFilename();
        // 获取文件的后缀
        String extension = FilenameUtils.getExtension(file.getOriginalFilename());
        // 根据日期动态的生成目录
        String localContainer = "/static/upload";
        String uploadPath = ResourceUtils.getURL("src/main/resources").getPath() + localContainer;
        String dateFormat = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
        File dateDirPath = new File(uploadPath + File.separator + dateFormat);
        if (!dateDirPath.exists()) {
            dateDirPath.mkdirs();
        }
        String session01 = localContainer.substring(localContainer.lastIndexOf("/")) + "/" + dateFormat + "/" + fileName;
        // 处理文件上传
        file.transferTo(new File(dateDirPath, fileName));
        Product product = (Product) session.getAttribute("product");
        //添加
        product.setProductimg(session01);
        int i = productService.SchoolUpdate(product);
        return "redirect:/product/sel";
    }

    @ResponseBody
    @RequestMapping("/upd")
    public int update2(Product product) {
        int i = productService.SchoolUpdate2(product);
        return i;
    }
    @ResponseBody
    @RequestMapping("/insert1")
    public int insert1(Product product) {
        int i = productService.insert1(product);
        return i;
    }
}
