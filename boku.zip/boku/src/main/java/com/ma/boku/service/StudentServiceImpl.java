package com.ma.boku.service;

import com.ma.boku.mapper.StudentMapper;
import com.ma.boku.pojo.School;
import com.ma.boku.pojo.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentServiceImpl implements StudentService {
    @Autowired
    private StudentMapper studentMapper;
    @Override
    public List<School> studentList(School school) {
        return studentMapper.studentList(school);
    }

    @Override
    public School findByID(Integer id) {
        return studentMapper.findByID(id);
    }


    @Override
    public List<School> findschool() {
        return studentMapper.findschool();
    }

    @Override
    public int add(User user) {
        return studentMapper.add(user);
    }

    @Override
    public int upd(User user) {
        return studentMapper.upd(user);
    }

    @Override
    public int del(int id) {
        return studentMapper.del(id);
    }

    @Override
    public List<School> studentList1(String name) {
        return studentMapper.studentList1(name);
    }

}
