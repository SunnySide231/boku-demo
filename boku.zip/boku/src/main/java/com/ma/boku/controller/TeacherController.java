package com.ma.boku.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.ma.boku.pojo.School;
import com.ma.boku.pojo.User;
import com.ma.boku.service.TeacherService;
import com.ma.boku.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
@RequestMapping("/teacher")
public class TeacherController {
    @Autowired
    private TeacherService teacherService;

    @RequestMapping("/list")
    public String list(School school, Model model, @RequestParam(defaultValue = "1") int pageNum, @RequestParam(defaultValue = "10") int pageSize) {
        PageHelper.startPage(pageNum,pageSize);
        List<School> teacher_list = teacherService.teacherList(school);
        PageInfo<School> schoolPageInfo = new PageInfo<School>(teacher_list);
        model.addAttribute("schoolPageInfo", schoolPageInfo);
        return "teacher_list";
    }

    @RequestMapping("/edit")
    public String edit(String name,School school, Model model, @RequestParam(defaultValue = "1") int pageNum, @RequestParam(defaultValue = "8") int pageSize) {
        PageHelper.startPage(pageNum,pageSize);
        if (name==null){
            List<School> teacher_list = teacherService.teacherList(school);
            PageInfo<School> schoolPageInfo = new PageInfo<School>(teacher_list);
            model.addAttribute("schoolPageInfo", schoolPageInfo);
            model.addAttribute("name",name);
        }else{
            List<School> teacher_list = teacherService.selteacher(name);
            PageInfo<School> schoolPageInfo = new PageInfo<School>(teacher_list);
            model.addAttribute("schoolPageInfo", schoolPageInfo);
            model.addAttribute("name",name);
        }
        return "teacher_edit";
    }

    @RequestMapping("/findByID")
    @ResponseBody
    public School account_findByID(Integer id) {
        School school = teacherService.findByID(id);
        return school;
    }

    @RequestMapping("/add")
    @ResponseBody
    public int add(User user) {
        int i = teacherService.add(user);
        if (i>0){
            return i;
        }
        return 0;
    }

    @RequestMapping("/upd")
    @ResponseBody
    public int upd(User user) {
        int i = teacherService.upd(user);
        if (i>0){
            return i;
        }
        return 0;
    }
    @RequestMapping("/deleteByid")
    public String deleteByid(int id) {
        int i = teacherService.deleteByid(id);
        if (i>0){
            return "redirect:/teacher/edit";
        }
        return "404";
    }
}
