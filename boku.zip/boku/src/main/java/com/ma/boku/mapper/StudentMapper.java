package com.ma.boku.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ma.boku.pojo.School;
import com.ma.boku.pojo.User;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface StudentMapper extends BaseMapper<School> {

    List<School> studentList(School school);

    School findByID(Integer id);

    //@Insert("insert into user (id,account,username,password,tel,home,schoolid,rid) values(null,#{account},#{username},#{password},#{tel},#{home},#{schoolid},#{rid})")
    int insert(User user);

    @Select("select distinct id, schoolname from school")
    List<School> findschool();

    @Insert("insert into user values(null,#{account},#{username},#{password},#{tel},#{home},#{schoolid},3,#{integral})")
    int add(User user);

    @Update("update user set username=#{username},tel=#{tel},home=#{home},schoolid=#{schoolid} where id = #{id}")
    int upd(User user);

    @Delete("delete from user where id = #{id}")
    int del(int id);

    List<School> studentList1(String name);
}
